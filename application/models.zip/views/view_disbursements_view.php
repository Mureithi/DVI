<script type="text/javascript">
function cleanup(){
}
</script>
<div class="section_title"><?php echo $title;?></div>
<?php
$this->load->view('vaccine_tabs');
?>
<div id="BCG">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For BCG</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>
<div id="polio">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For Polio</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>
<div id="pneumococcal">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For
	Pneumoccocal</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a>
		<a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="measles">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For Measles</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a>
		<a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="pentavalent">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For
	Pentavalent</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a>
		<a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="yellow_fever">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For Yellow
	Fever</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a>
		<a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="rotavirus">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Vaccines Issued For Rotavirus</th>
	<tr>
		<th>Date Issued</th>
		<th>Issued to</th>
		<th>Voucher Number</th>
		<th>Quantity Issued</th>
		<th>Batch Number</th>
		<th>Stock Remaining</th>
		<th>Comments</th>
		<th>Entered By</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>4-Jan-11</td>
		<td>NZAUI</td>
		<td>VAC001</td>
		<td>1000</td>
		<td><a href="#" class="link">A725LAMF</a></td>
		<td>23000</td>
		<td>Comment</td>
		<td>User 1</td>
		<td><a href="#" class="link">Edit</a>
		<a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>
