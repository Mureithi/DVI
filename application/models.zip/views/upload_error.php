<div class="message error close">
	<h2>Error!</h2>
	<p>
		<?php echo  $error;?>
	</p>
</div>