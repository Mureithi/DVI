<script type="text/javascript">
function cleanup(){
}
</script>
<div class="section_title"><?php echo $title;?></div>
<?php
$this->load->view('vaccine_tabs');
?>
<div id="BCG">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For BCG</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
<td colspan="3">Not yet Set</td>
	</tr>


</table>
</div>
<div id="polio">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Polio</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
<td colspan="3">Not yet Set</td>
	</tr>


</table>
</div>
<div id="pneumococcal">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Pneumoccocal
	</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
		<td colspan="3">Not yet Set</td>
	</tr>


</table>
</div>

<div id="measles">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Measles</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>300</td>
		<td>0727548526,0723656985</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="pentavalent">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Pentavalent
	</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>7000</td>
		<td>0750254875,0770896325,0725145236,0722125456</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="yellow_fever">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Yellow Fever
	</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>3400</td>
		<td>0727524158,0712548789,0735458796,0710254789</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>

<div id="rotavirus">
<table border="0" class="data-table">
	<th class="subsection-title" colspan="9">Added Batches For Rotavirus</th>
	<tr>
		<th>Stock Level</th>
		<th>Text Message Recepients</th>
		<th>Action</th>
	</tr>
	<tr>
		<td>2000</td>
		<td>0735214528,0770542563,0728754125,0731025418</td>
		<td><a href="#" class="link">Edit</a> <a href="#" class="link">Delete</a>
		</td>
	</tr>


</table>
</div>
