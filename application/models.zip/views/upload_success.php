<div class="message information close">
	<h2>Success!</h2>
	<p>
		Upload successful, <?php echo  $records;?> records were imported into the system
	</p>
</div>