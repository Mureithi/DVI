<?php
class MOS_Trend extends MY_Controller {
	function __construct() {
		parent::__construct();

	}

	public function get($vaccine, $year = "", $national = "", $region = "", $district = "") {
		if ($national > 0) {
			$title = "MOS Available at Central Vaccine Store";
		}
		if ($region > 0) {
			$region_object = Regions::getRegion($region);
			$title = "MOS Available at " . $region_object -> name;
		}
		if ($district > 0) {
			$district_object = Districts::getDistrict($district);
			$title = "MOS Available at " . $district_object -> name . " District Store";
		}
		$monthly_opening_stocks = array();
		$vaccine_objects = array();
		if ($year == "0") {
			$year = date('Y');
		}
		if ($vaccine == "0") {
			$vaccine_object = Vaccines::getFirstVaccine();
			$vaccine_objects[0] = $vaccine_object;
		} else if (strlen($vaccine) > 0) {
			$vaccines_array = explode('-', $vaccine);
			$counter = 0;
			foreach ($vaccines_array as $vaccines_element) {
				if (strlen($vaccines_element) > 0) {
					$vaccine_object = Vaccines::getVaccine($vaccines_element);
					$vaccine_objects[$counter] = $vaccine_object;
				}
				$counter++;
			}
		}
		$year_start = date("U", mktime(0, 0, 0, 1, 1, $year));

		$counter = 2;
		$population = 0;

		if ($national > 0) {
			$population = Regional_Populations::getNationalPopulation($year);
		}
		if ($region > 0) {
			$population = Regional_Populations::getRegionalPopulation($region, $year);
		}
		if ($district > 0) {
			$population = District_Populations::getDistrictPopulation($district, $year);
		}
		$population = str_replace(",", "", $population);

		foreach ($vaccine_objects as $vaccine_object) {
			$monthly_requirement = ceil(($vaccine_object -> Doses_Required * $population * $vaccine_object -> Wastage_Factor) / 12);
			for ($month = 1; $month <= 36; $month++) {
				$stock_balance = 0;
				$mos_balance = 0;
				//Get the month
				$month_number = ceil($month / 3);
				//If it is an even number, get values for the 21st, if it's odd, get values for the 7th
				if ($month % 3 == 0) {
					$month_date = 28;
				} else if ($month % 3 == 1) {
					$month_date = 7;
				} else if ($month % 3 == 2) {
					$month_date = 21;
				}
				$to = date("U", mktime(0, 0, 0, $month_number, $month_date, $year));
				if ($national > 0) {
					$stock_balance = Disbursements::getNationalPeriodBalance($vaccine_object -> id, $to);
				}
				if ($region > 0) {
					$stock_balance = Disbursements::getRegionalPeriodBalance($region, $vaccine_object -> id, $to);
				}
				if ($district > 0) {
					$stock_balance = Disbursements::getDistrictPeriodBalance($district, $vaccine_object -> id, $to);
				}
				if ($stock_balance > 0) {
					$mos_balance = number_format(($stock_balance / $monthly_requirement), 2);
				}
				$monthly_opening_stocks[$vaccine_object -> id][$month] = $mos_balance;
				$counter += 2;
			}
		}

		$chart = '
<chart bgColor="FFFFFF" showBorder="0" showAlternateHGridColor="0" divLineAlpha="10" caption="Monthly Stock at Hand Summary" subcaption="For the year ' . $year . '" xAxisName="Month" yAxisName="Months of Stock"  showValues="0" >
<categories>
<category label="Jan"/>
<category label=""/>
<category label=""/>
<category label="Feb"/>
<category label=""/>
<category label=""/>
<category label="Mar"/>
<category label=""/>
<category label=""/>
<category label="Apr"/>
<category label=""/>
<category label=""/>
<category label="May"/>
<category label=""/>
<category label=""/>
<category label="Jun"/>
<category label=""/>
<category label=""/>
<category label="Jul"/>
<category label=""/>
<category label=""/>
<category label="Aug"/>
<category label=""/>
<category label=""/>
<category label="Sep"/>
<category label=""/>
<category label=""/>
<category label="Oct"/>
<category label=""/>
<category label=""/>
<category label="Nov"/>
<category label=""/>
<category label=""/>
<category label="Dec"/>
<category label=""/>
<category label=""/>
</categories> 
<dataset seriesName="2 Months of Stock (Ideal Stock Level)" color="269600" anchorBorderColor="269600" anchorBgColor="269600">';

		for ($x = 1; $x <= 36; $x++) {
			$chart .= '<set value="2"/>';
		}

		$chart .= '</dataset>';
		foreach ($vaccine_objects as $vaccine_object) {
			$chart .= '<dataset seriesName="' . $vaccine_object -> Name . ' Balance">
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][1] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][2] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][3] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][4] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][5] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][6] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][7] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][8] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][9] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][10] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][11] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][12] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][13] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][14] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][15] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][16] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][17] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][18] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][19] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][20] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][21] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][22] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][23] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][24] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][25] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][26] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][27] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][28] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][29] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][30] . '"/>
<set value="' . $monthly_opening_stocks[$vaccine_object -> id][31] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][32] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][33] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][34] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][35] . '"/>
<set  value="' . $monthly_opening_stocks[$vaccine_object -> id][36] . '"/> 
</dataset>';
		}
		$chart .= '<styles>
<definition>
<style name="Anim1" type="animation" param="_xscale" start="0" duration="1"/>
<style name="Anim2" type="animation" param="_alpha" start="0" duration="0.6"/>
<style name="DataShadow" type="Shadow" alpha="40"/>
</definition>
<application>
<apply toObject="DIVLINES" styles="Anim1"/>
<apply toObject="HGRID" styles="Anim2"/>
<apply toObject="DATALABELS" styles="DataShadow,Anim2"/>
</application>
</styles>
</chart>
';

		echo $chart;
	}

	public function download_mos_trend($selected_year = 0, $national = "", $region = "", $district = "") {
		$year = date('Y');
		if ($selected_year != "0") {
			$year = $selected_year;
		}

		$counter = 2;
		$vaccine_objects = Vaccines::getAll();
		$population = 0;
		$title = "";
		if ($national > 0) {
			$title = "MOS Balance Trend at Central Vaccine Store";
			$population = Regional_Populations::getNationalPopulation($year);
		}
		if ($region > 0) {
			$region_object = Regions::getRegion($region);
			$title = "MOS Balance Trend at " . $region_object -> name;
			$population = Regional_Populations::getRegionalPopulation($region, $year);
		}
		if ($district > 0) {
			$district_object = Districts::getDistrict($district);
			$title = "MOS Balance Trend at " . $district_object -> name . " District Store";
			$population = District_Populations::getDistrictPopulation($district, $year);
		}
		$population = str_replace(",", "", $population);

		foreach ($vaccine_objects as $vaccine_object) {
			$monthly_requirement = ceil(($vaccine_object -> Doses_Required * $population * $vaccine_object -> Wastage_Factor) / 12);
			for ($month = 1; $month <= 36; $month++) {
				$mos_balance = 0;
				//Get the month
				$month_number = ceil($month / 3);
				//If it is an even number, get values for the 21st, if it's odd, get values for the 7th
				if ($month % 3 == 0) {
					$month_date = 28;
				} else if ($month % 3 == 1) {
					$month_date = 7;
				} else if ($month % 3 == 2) {
					$month_date = 21;
				}
				$to = date("U", mktime(0, 0, 0, $month_number, $month_date, $year));
				$stock_balance = 0;
				if ($national > 0) {
					$stock_balance = Disbursements::getNationalPeriodBalance($vaccine_object -> id, $to);
				}
				if ($region > 0) {
					$stock_balance = Disbursements::getRegionalPeriodBalance($region, $vaccine_object -> id, $to);
				}
				if ($district > 0) {
					$stock_balance = Disbursements::getDistrictPeriodBalance($district, $vaccine_object -> id, $to);
				}
				//$stock_balance = 0;
				if ($stock_balance > 0) {
					$mos_balance = number_format(($stock_balance / $monthly_requirement), 2);
				}
				$monthly_opening_stocks[$month][$vaccine_object -> id]['stock_balance'] = number_format($stock_balance + 0);
				$monthly_opening_stocks[$month][$vaccine_object -> id]['mos_balance'] = $mos_balance;
				$counter += 2;
			}
		}
		$data_buffer = "
			<style>
			table.data-table {
			table-layout: fixed;
			width: 1000px;
			border-collapse:collapse;
			border:1px solid black;
			}
			table.data-table td, th {
			width: 100px;
			border: 1px solid black;
			}
			.leftie{
				text-align: left !important;
			}
			.center{
				text-align: center !important;
			}
			.right{
				text-align: right !important;
			}
			</style> 
			";
		$data_buffer .= "<table class='data-table'>";
		$counter = 2;
		$data_buffer .= $this -> echoTitles($vaccine_objects);
		for ($month = 1; $month <= 36; $month++) {
			$data_buffer .= "<tr>";
			$month_number = ceil($month / 3);
			//If it is an even number, get values for the 21st, if it's odd, get values for the 7th
			if ($month % 3 == 0) {
				$month_date = 28;
			} else if ($month % 3 == 1) {
				$month_date = 7;
			} else if ($month % 3 == 2) {
				$month_date = 21;
			}
			$date = date("M-d", mktime(0, 0, 0, $month_number, $month_date, $year));
			$data_buffer .= "<td>" . $date . "</td>";
			foreach ($vaccine_objects as $vaccine_object) {
				$data_buffer .= "<td class='center'>" . $monthly_opening_stocks[$month][$vaccine_object -> id]['mos_balance'] . "</td><td class='right'>" . $monthly_opening_stocks[$month][$vaccine_object -> id]['stock_balance'] . "</td>";
			}
			$data_buffer .= "</tr>";
			$counter += 2;
		}
		$data_buffer .= "</table>";
		$this -> generatePDF($data_buffer, $year,$title);
		//	var_dump($monthly_opening_stocks);
	}

	function generatePDF($data, $year,$title) {
		$html_title = "<img src='Images/coat_of_arms-resized.png' style='position:absolute; width:96px; height:92px; top:0px; left:0px; '></img>";
		$html_title .= "<h3 style='text-align:center; text-decoration:underline; margin-top:-50px;'>".$title."</h3>";
		$date = date('d-M-Y');
		$html_title .= "<h5 style='text-align:center;'> for the year: " . $year . " as at: " . $date . "</h5>";

		$this -> load -> library('mpdf');
		$this -> mpdf = new mPDF('c', 'A4-L');
		$this -> mpdf -> SetTitle('Monthly Stock At Hand Summary');
		$this -> mpdf -> WriteHTML($html_title);
		$this -> mpdf -> simpleTables = true;
		$this -> mpdf -> WriteHTML($data);
		$this -> mpdf -> WriteHTML($html_footer);
		$report_name = "Monthly Stock At Hand Summary.pdf";
		$this -> mpdf -> Output($report_name, 'D');
	}

	public function echoTitles($vaccines) {
		$initial_headers = "<tr><th rowspan='2'>Date</th>";
		foreach ($vaccines as $vaccine) {
			$initial_headers .= "<th colspan='2'>" . $vaccine -> Name . "</th>";
		}
		$initial_headers .= "</tr><tr>";
		foreach ($vaccines as $vaccine) {
			$initial_headers .= "<th>MOS</th><th>Stock</th>";
		}
		$initial_headers .= "</tr>";
		return $initial_headers;
	}

}
